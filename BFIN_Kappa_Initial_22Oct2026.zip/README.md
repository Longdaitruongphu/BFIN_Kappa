# Kappa Foundation | initial submission package | 22 October 2026

This is a **prepared** initial submission, not an upload receipt or trustees' authorization. The case decision and information cutoff are 31 December 2022. The PDF in `deliverables/` is the two-page Initial Decision Record. `policy/initial_policy_proposed.json` is its machine-readable policy snapshot. Keep this entire package unchanged once submitted.

## Read and rebuild in three steps

1. Read `deliverables/Kappa_Initial_Decision_Record_22Oct2026.pdf` (two pages), then `data/DATA_RECORD.md` for the source chain and limitations.
2. In Python 3.12 or 3.13, install `requirements-analysis.txt` and run `python analysis/run_initial.py` from this package directory. It uses the saved `data/raw/train/` files only, requires no internet, verifies eleven training-source hashes plus four supporting-source hashes, and writes the analysis under `outputs/`. Read `outputs/initial_decision_rebuild.json` for the full budget and goal; `outputs/growth_portfolio_weights.csv` for the selected and benchmark weights; `outputs/candidate_statistics.csv` for CAPM inputs; `outputs/risk_preference.csv` for the A = 2/4/6/8 comparison; and `outputs/sample_utility_robustness.json` for the unconstrained A=4 challenger and 60-month stability check. To regenerate the PDF after the analysis, run `python analysis/build_initial_pdf.py`.
3. `python analysis/retrieve_data.py --phase train` is the original working **online retrieval code**. Run it only when intentionally fetching into a clean copy: the existing raw files are the dated source record and should not be overwritten. Its Yahoo settings and Kenneth French URL appear in `data/raw/retrieval_manifest.jsonl`.

The CSV daily downloads retain Yahoo's `Close`, `Adj Close`, dividends and stock splits; the French ZIP is intact. The analysis takes the last trading day per month, forms month-to-month adjusted-price returns, and divides French's percentage factors (including RF) by 100. December 2014 is the baseline for the January 2015 return. Exactly 96 common monthly observations run from January 2015 through December 2022. No 2023–25 equity file is in this package or read by `run_initial.py`.

The decision is a proposal, not a guarantee: bonds meet fixed nominal payments under the case's no-default assumption; the CPI-adjusted 2030 goal and drawdown controls cannot be guaranteed. The case is retrospective, and vendor histories downloaded in 2026 may differ from data displayed in 2022. See the data record before interpreting the results as a live backtest.
