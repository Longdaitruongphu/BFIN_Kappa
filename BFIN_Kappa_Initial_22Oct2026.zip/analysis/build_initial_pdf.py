"""Typeset the two-page initial decision record from the verified 2022 case inputs."""
from __future__ import annotations

import json
from pathlib import Path

from pypdf import PdfReader
from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Table, TableStyle

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / "outputs/initial_decision_rebuild.json").read_text(encoding="utf-8"))
CHALLENGER = json.loads((ROOT / "outputs/sample_utility_robustness.json").read_text(encoding="utf-8"))
DEST = ROOT / "deliverables/Kappa_Initial_Decision_Record_22Oct2026.pdf"
FONT = Path("C:/Windows/Fonts")
pdfmetrics.registerFont(TTFont("Segoe", str(FONT / "segoeui.ttf")))
pdfmetrics.registerFont(TTFont("Segoe-Bold", str(FONT / "segoeuib.ttf")))
pdfmetrics.registerFontFamily("Segoe", normal="Segoe", bold="Segoe-Bold")
W, H = A4
L, R = 43, W - 43
WIDTH = R - L
INK = colors.HexColor("#1C2E3A")
MUTED = colors.HexColor("#54616A")
RULE = colors.HexColor("#BDC8CE")
PALE = colors.HexColor("#F4F6F7")
ACCENT = colors.HexColor("#325D72")

STYLES = {
    "body": ParagraphStyle("body", fontName="Segoe", fontSize=9.8, leading=14, textColor=INK),
    "small": ParagraphStyle("small", fontName="Segoe", fontSize=8.9, leading=12.3, textColor=MUTED),
    "cell": ParagraphStyle("cell", fontName="Segoe", fontSize=8.9, leading=12.1, textColor=INK),
    "cellbold": ParagraphStyle("cellbold", fontName="Segoe-Bold", fontSize=8.9, leading=12.1, textColor=INK),
    "right": ParagraphStyle("right", fontName="Segoe", fontSize=8.9, leading=12.1, textColor=INK, alignment=TA_RIGHT),
    "rightbold": ParagraphStyle("rightbold", fontName="Segoe-Bold", fontSize=8.9, leading=12.1, textColor=INK, alignment=TA_RIGHT),
}


def p(c, content, y, kind="body", x=L, width=WIDTH):
    element = Paragraph(content, STYLES[kind])
    _, height = element.wrap(width, 1000)
    element.drawOn(c, x, y - height)
    return y - height


def head(c, page, subtitle):
    c.setFillColor(ACCENT)
    c.setFont("Segoe-Bold", 8)
    c.drawString(L, H - 36, "KAPPA FOUNDATION")
    c.setFont("Segoe", 8)
    c.drawRightString(R, H - 36, "INVESTMENT COMMITTEE  |  22 OCTOBER 2026")
    c.setStrokeColor(RULE)
    c.setLineWidth(.7)
    c.line(L, H - 44, R, H - 44)
    c.setFillColor(INK)
    c.setFont("Segoe-Bold", 18)
    c.drawString(L, H - 73, "Initial decision record" if page == 1 else "Policy and verification")
    c.setFillColor(MUTED)
    c.setFont("Segoe", 8.3)
    c.drawString(L, H - 89, subtitle)
    c.line(L, 38, R, 38)
    c.setFont("Segoe", 7.5)
    c.drawString(L, 25, "Case decision date: 31 December 2022  |  USD unless stated")
    c.drawRightString(R, 25, f"{page} / 2")
    return H - 108


def section(c, title, y):
    y -= 13
    c.setFont("Segoe-Bold", 10.1)
    c.setFillColor(INK)
    c.drawString(L, y, title)
    c.setStrokeColor(RULE)
    c.line(L, y - 5, R, y - 5)
    return y - 13


def table(c, rows, widths, y, right=(), highlight=()):
    content = []
    for i, row in enumerate(rows):
        cells = []
        for j, value in enumerate(row):
            kind = "rightbold" if j in right and i == 0 else "right" if j in right else "cellbold" if i == 0 else "cell"
            cells.append(Paragraph(value, STYLES[kind]))
        content.append(cells)
    t = Table(content, colWidths=widths, hAlign="LEFT")
    command = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LINEBELOW", (0, 0), (-1, 0), .75, INK),
        ("LINEBELOW", (0, -1), (-1, -1), .65, RULE),
    ]
    for r in highlight:
        command.append(("BACKGROUND", (0, r), (-1, r), PALE))
    t.setStyle(TableStyle(command))
    _, h = t.wrap(WIDTH, 1000)
    t.drawOn(c, L, y - h)
    return y - h


def main():
    assert DATA["growth_etf"] == "USMV"
    assert abs(DATA["total_initial_budget"] - 12_000_000) < .001
    c = canvas.Canvas(str(DEST), pagesize=A4, pageCompression=1)
    c.setTitle("Kappa Foundation | Initial decision record | 22 October 2026")
    c.setAuthor("Kappa Foundation independent investment team - draft for trustee review")

    y = head(c, 1, "Proposed allocation and the evidence available at the 2022 decision date")
    y = p(c, "<b>Recommendation.</b> Buy the case Beta and Delta bonds in amounts that pay the two fixed commitments without selling equities. Invest the remaining USD 6.346m in the USMV equity ETF. The 2030 real-value target is a planning goal, not an insured payment; the equity allocation can lose value.", y)

    y = section(c, "Funding comes before portfolio selection", y)
    y = table(c, [
        ["Use of initial USD 12m", "Instrument and contractual cash flow", "Initial USD"],
        ["2024 scholarship", "2,400 Beta zeros; USD 2.400m at maturity", "2,214,672"],
        ["2027 learning centre", "3,478.26087 Delta; final cash flow USD 3.600m", "3,429,809"],
        ["Growth sleeve", "USMV, after 10bp assumed entry cost", "6,346,351"],
        ["Execution allowance", "5bp on case bonds; 10bp on equity", "9,169"],
        ["Total", "No borrowing or unallocated initial cash", "12,000,000"],
    ], [147, 267, WIDTH - 414], y, right=(2,), highlight=(3,))
    y -= 6
    y = p(c, "Beta meets the 31 Dec 2024 invoice; Delta's final coupon and principal meet 31 Dec 2027. Four earlier Delta coupons total USD 486,957 and are held as cash at 0% in the base plan. The funding test does not assume a coupon reinvestment return or a future bond sale price.", y, "small")

    y = section(c, "Growth allocation and competing models", y)
    y = p(c, "The research set contains eight US stocks in seven sectors - AAPL, MSFT, JPM, JNJ, PG, XOM, CAT and NEE - plus USMV (minimum-volatility US equities) and VTI (the broad US market). These are candidates, not ten mandatory holdings. VTI is the simple, investable comparator and the rejected growth allocation.", y)
    y -= 6
    y = table(c, [
        ["2022-input comparison", "USMV 100%", "VTI 100%", "Sample utility maximum"],
        ["Annual CAPM return scenario", "7.14%", "8.45%", f"{CHALLENGER['expected_return']:.2%}"],
        ["Annual sample volatility", "12.84%", "16.31%", f"{CHALLENGER['volatility']:.2%}"],
        ["Utility at A = 4", "3.84%", "3.13%", f"{CHALLENGER['utility_A4']:.2%}"],
    ], [199, 84, 84, WIDTH - 367], y, right=(1, 2, 3), highlight=(3,))
    y -= 6
    utility_delta_pp = 100 * (CHALLENGER["utility_A4"] - DATA["forecast_comparison"]["USMV"]["utility_A4"])
    turnover_pct = 100 * CHALLENGER["one_way_turnover_96m_to_60m"]
    y = p(c, f"Utility is expected annual return less <b>2 x annual variance</b> when risk aversion A = 4. CAPM uses a 4% prospective risk-free scenario, 4.5% market premium and 2015-22 estimated betas; forecast alpha is zero. Unrestricted sample optimization improves the modeled utility over USMV by only {utility_delta_pp:.2f} percentage point and changes {turnover_pct:.1f}% of the sleeve when the estimation window is shortened from 96 to 60 months. We prefer the simpler USMV mandate until a more stable forecast supports active stock weights. USMV is <b>not</b> the mathematical maximum of the 96-month sample model.", y, "small")
    if y < 51:
        raise RuntimeError(f"Page 1 overflow: {y:.1f}")
    c.showPage()

    y = head(c, 2, "Rules fixed before the 2023-25 evaluation; committee review is distinct from a price stop")
    y = section(c, "Assumptions the trustees are being asked to approve", y)
    y = table(c, [
        ["Subject", "Working convention and decision use"],
        ["2030 real goal", "USD 8m in Dec 2022 purchasing power. CPI 2.5% base implies USD 9.747m nominal in 2030; 3.0% education-cost stress implies USD 10.134m. The growth sleeve needs 4.84% and 5.37% nominal CAGR respectively, including the four coupons held at 0%."],
        ["Return and risk", "A = 4 is provisional; compare A = 2, 4, 6, 8. The 2015-22 sample covariance is the common comparison scale; single-index covariance and a 60-month window are robustness checks. No extra per-stock weight cap has been approved."],
        ["Permitted assets", "Cash, the five case bonds, US common stocks and US-listed US-equity ETFs. Long-only; no borrowing or derivatives. Proposed entry friction: 5bp bonds, 10bp equity."],
    ], [105, WIDTH - 105], y)

    y = section(c, "Monitoring and authority", y)
    y = p(c, "Measure the growth sleeve's <b>unitized total-return drawdown</b> from its running peak. Keep the bond-payment coverage and whole-fund value on separate lines. The thresholds below trigger a review, not an automatic sell order or a guarantee against losses.", y, "small")
    y -= 6
    y = table(c, [
        ["Signal", "Required response"],
        ["10% sleeve loss", "Check data, near-term payment coverage and stress within two business days."],
        ["15% sleeve loss", "Investment Committee meets within five business days; document hold, rule-based rebalance or a prospective policy proposal."],
        ["20% sleeve loss", "Escalate to trustees the same or next business day and pause discretionary risk increases."],
        ["Any payment gap", "Escalate immediately with a funded remedy; no crisis exception may impair a due payment."],
    ], [109, WIDTH - 109], y)
    y -= 6
    y = p(c, "<b>On gains:</b> review annually. If the 2030 goal remains fundable after a separate 30% growth-sleeve shock, trustees may prospectively protect only the amount needed for that goal using an eligible asset at an actual available price. Gains alone do not authorize higher spending or an automatic sale.", y, "small")

    y = section(c, "Frozen evaluation and reproducibility", y)
    y = p(c, "Use 96 common monthly adjusted-close returns, Jan 2015-Dec 2022; the Dec 2014 close supplies the first return. Freeze USMV and VTI at 31 Dec 2022. Compare their Jan 2023-Dec 2025 total-return paths with the same 10bp trade-cost assumption and a declared annual December rebalance to original weights; no future observation may change the 2022 choice. Revisit a decision only after checking payments, risk capacity, expected-return evidence and implementation cost.", y, "small")
    y -= 5
    y = p(c, "<b>Rebuild:</b> read <i>data/DATA_RECORD.md</i> and <i>data/raw/retrieval_manifest.jsonl</i>; install <i>requirements-analysis.txt</i>; run <i>python analysis/run_initial.py</i> offline. Inspect <i>outputs/initial_decision_rebuild.json</i>, <i>growth_portfolio_weights.csv</i>, <i>candidate_statistics.csv</i>, <i>risk_preference.csv</i> and <i>sample_utility_robustness.json</i>. The retrieval program is <i>analysis/retrieve_data.py --phase train</i>. Saved Yahoo/French bytes are hashed; 2026 vendor history is retrospective, and SEC eligibility references are not archived filing bytes.", y, "small")
    y -= 5
    y = p(c, "<b>Scope:</b> this two-page record contains the initial allocation and predeclared rule required on 22 Oct. Bond curve shocks, full sample-versus-index portfolio tests, factor inference and 2023-25 outcomes require separate evidence in the final 29 Oct committee memo. Neither adviser has been vindicated by this initial record.", y, "small")
    if y < 51:
        raise RuntimeError(f"Page 2 overflow: {y:.1f}")
    c.showPage()
    c.save()
    assert len(PdfReader(str(DEST)).pages) == 2
    print(f"PDF complete: {DEST}; p2 clearance {y:.1f} pt")


if __name__ == "__main__":
    main()
